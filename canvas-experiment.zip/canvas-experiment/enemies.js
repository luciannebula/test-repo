const enemies =[];

class Enemy {
    constructor(image, sx, sy, swidth, sheight, dx, dy, dw, dh, speed, moving){
        this.sx = sx;
        this.sy = sy;
        this.swidth = swidth;
        this.sheight = sheight;
        this.dx = dx;
        this.dy = dy;
        this.dw = dw;
        this.dh = dh;
        this.speed = speed;
        this.moving = moving;
        this.image = image;
        this.frameY = 0;
        enemies.push(this);
    }

    moveLeft(x){
     this.dx -= x;  
    }

  
    destroy(){
      let index = enemies.indexOf(this);
      enemies.splice(index, 1);  
    }
   
    
    

    returnSpriteValues(){
        return [
            this.image, 
            this.sx, this.sy, 
            this.swidth, this.sheight, 
            this.dx, this.dy,
            this.dw, this.dh
        ]
    }
    

    drawSprite(ctx){
        ctx.drawImage(this.image, this.sx, this.sy, this.swidth, this.sheight, this.dx, this.dy, this.dw, this.dh);
    }
    
};


const enemySprite = new Image();
enemySprite.src = "images/enemysprite.png";

const eVals = {
    sx: 0,
    sy: (enemySprite.height/20),
    sWidth: enemySprite.width/3,
    sHeight: enemySprite.height,
    dx:700,
    dy:700,
    dWidth: (enemySprite.width/20)/3,
    dHeight: (enemySprite.height/20),
}
//console.log(enemySprite.width/20, enemySprite.height/20)

function drawSprite(img, sX, sY, sW, sH, dX, dY, dW, dH){
    ctx.drawImage(img, sX, sY, sW, sH, dX, dY, dW, dH);
}



const testEnemy = new Enemy(enemySprite, eVals.sx, eVals.sy, eVals.sWidth, eVals.sHeight, eVals.dx, eVals.dy, eVals.dWidth, eVals.dHeight);

setInterval(newEnemies, 8000);

function newEnemies(){
    new Enemy(enemySprite, eVals.sx, eVals.sy, eVals.sWidth, eVals.sHeight, eVals.dx, eVals.dy, eVals.dWidth, eVals.dHeight)

};
//enemies.push(testEnemy);



        // this.x= 300;
        // this.y= 400;
        // this.width= 200;
        // this.height= 200;
        // this.frameX= 0;
        // this.frameY= 0;
        // this.speed= 10;
        // this.moving= true;
